import vk_api
from vk_api.bot_longpoll import VkBotLongPoll, VkBotEventType
from vk_api.keyboard import VkKeyboard, VkKeyboardColor
from random import randint as random
import datetime
from time import sleep
import json
import re
from PIL import Image,ImageFont,ImageDraw
import requests

def upd(str):
    ls = json.load(open("bd.json", "r", encoding="utf-8"))
    ls.update(str)
    with open('bd.json', 'w', encoding="utf-8") as f:
        json.dump(ls, f, indent=4, ensure_ascii = False)
        f.close()

def loli_license(name):
    img = Image.open("/root/vkbot-env/loli.png")
    draw = ImageDraw.Draw(img)
    font = ImageFont.truetype("/root/vkbot-env/DINNextCYR-BoldItalic.otf", 60)
    today = datetime.datetime.today()
    time = today.strftime("%d.%m.%Y")
    draw.text((600, 425),name,(0,0,0),font=font)
    draw.text((520, 595),time,(0,0,0),font=font)
    img.save('/root/vkbot-env/loli2.png')

def log(event):
    today = datetime.datetime.today()
    file = open("my.log",'a')
    file.write(today.strftime("%d.%m.%Y %H:%M:%S") + ', Text from: '+str(event.obj.from_id)+ ', Text: '+str(event.obj.text))
    file.write("\n")
    file.close()
    #print(today.strftime("%d.%m.%Y %H:%M:%S") + ' Text from: '+str(event.user_id)+ ' Text: '+str(event.text))

vk_session = vk_api.VkApi(token='')

longpoll = VkBotLongPoll(vk_session, '166545677')

vk = vk_session.get_api()

keyboard = VkKeyboard(one_time=True)
keyboard.add_button('Пак', color=VkKeyboardColor.POSITIVE)
while True:
    try:
        for event in longpoll.listen():
            log(event)
            if event.type == VkBotEventType.MESSAGE_NEW and event.from_chat:
                text = str(event.obj.text)
                if event.obj.text == "Начать":
                    strr = "Ок, начинай сосать, дядя))0)0))0"
                    vk.messages.send(chat_id = int(event.chat_id),message = strr ,random_id = random(10000,100000),attachment = "photo-166545677_457248564")
                today = datetime.datetime.today()
                strr = today.strftime("%d.%m.%Y %H:%M:%S") + ', Text from: '+str(event.obj.from_id)+ ', Text: '+str(event.obj.text) + " Status: Completed"	
        
                if event.obj.text == "Помощь" or event.obj.text == 'Помоги' or event.obj.text == 'ддз помощь': 
                    vk.messages.send(chat_id = int(event.chat_id),message ="Пишов нахуй",random_id = random(10000,100000), keyboard = keyboard.get_keyboard())
                    vk.messages.send(user_id=550760548,message = strr ,random_id = random(10000,100000))
                    ls = json.load(open("bd.json", "r", encoding="utf-8"))
                    if (str(event.obj.from_id) in ls) == False:
                        ids = {str(event.obj.from_id):{}}
                        upd(ids)        

                if event.obj.text == 'Пак' or event.obj.text == 'пак'  or event.obj.text == "[club166545677|Доски для твоего забора] Пак" or event.obj.text == "[club166545677|@lolidro4] Пак": 
          
                    if vk.groups.isMember(group_id = '166545677', user_id = event.obj.from_id) == 1:
                        print(vk.groups.isMember(group_id = '166545677', user_id = event.obj.from_id))
                        vk.messages.send(chat_id = int(event.chat_id),message ="https://yadi.sk/d/LIIC7R4_3ZrwDh  Вот ваш пак, хозяин",random_id = random(10000,100000))
                        vk.messages.send(user_id=550760548,message = strr ,random_id = random(10000,100000))
                        ls = json.load(open("bd.json", "r", encoding="utf-8"))
                        if (str(event.obj.from_id) in ls) == False:
                            ids = {str(event.obj.from_id):{}}
                            upd(ids)
                    else:
                        vk.messages.send(chat_id = int(event.chat_id),message ="Ты не подписался, но все равно просишь пак? Даю в последний раз...\n https://yadi.sk/d/LIIC7R4_3ZrwDh",random_id = random(10000,100000))

                if text.lower() == "эрик":
                    s = "Эрик, ты чо охуел??!"
                    vk.messages.send(chat_id = int(event.chat_id),message = s ,random_id = random(10000,100000))

                if text.lower().startswith("ддз повысить"):
                    user_id = re.findall(r'ддз повысить \[id(\d*)\|.*]', text.lower())[0]
                    print(user_id)
                    ls = json.load(open("bd.json", "r", encoding="utf-8"))
                    if "lvl" in ls[str(user_id)]["conv"][str(event.chat_id)]:
                        if ls[str(event.obj.from_id)]["conv"][str(event.chat_id)]["lvl"] > ls[str(user_id)]["conv"][str(event.chat_id)]["lvl"]:
                            ls[str(user_id)]["conv"][str(event.chat_id)]["lvl"]+=1
                            with open('bd.json', 'w', encoding="utf-8") as f:
                                json.dump(ls, f, indent=4, ensure_ascii = False)
                                f.close()
                            vk.messages.send(chat_id=event.chat_id, message = "Уровень доступа повышен",random_id = random(10000,100000))
                    else:
                        if ls[str(event.obj.from_id)]["conv"][str(event.chat_id)]["lvl"] >= 1:
                            ls[str(user_id)].update({"conv":{str(event.chat_id):{"lvl":0}}})
                            with open('bd.json', 'w', encoding="utf-8") as f:
                                json.dump(ls, f, indent=4, ensure_ascii = False)
                                f.close()
                            vk.messages.send(chat_id=event.chat_id, message = "Получен правовой протокол, уровень доступа: 0",random_id = random(10000,100000))
                    ls.close()
                    

                if text.lower().startswith("ддз кик"): 
                    ls = json.load(open("bd.json", "r", encoding="utf-8"))
                    if "lvl" in ls[str(event.obj.from_id)]:
                        if ls[str(event.obj.from_id)]["conv"][str(event.chat_id)]["lvl"] > 0:
                            user_id = re.findall(r'ддз кик \[id(\d*)\|.*]', text.lower())[0]
                            vk.messages.send(chat_id=event.chat_id, message = "Покасики лохб",random_id = random(10000,100000))
                            vk.messages.removeChatUser(user_id=user_id,chat_id=event.chat_id)
                            
                        else:
                            vk.messages.send(chat_id=event.chat_id, message = "Недостаточный уровень доступа. Необходим уровень доступа: 1",random_id = random(10000,100000))
                    else:
                        vk.messages.send(chat_id=event.chat_id, message = "У вас отсутствует наличие правового протокола",random_id = random(10000,100000))
                    ls.close()

                if text.lower() == "аниме говно" or text.lower() == "аниме сосать":
                    vk.messages.send(chat_id=event.chat_id, message = "Че сказал? Бан нахуй!",random_id = random(10000,100000))
                    vk.messages.removeChatUser(user_id=int(event.obj.from_id),chat_id=event.chat_id)

                if text.lower() == "ддз рег":
                    ls = json.load(open("bd.json", "r", encoding="utf-8"))
                    ls[str(event.obj.from_id)].update({"conv":{str(event.chat_id):{"lvl":5}}})
                    with open('bd.json', 'w', encoding="utf-8") as f:
                        json.dump(ls, f, indent=4, ensure_ascii = False)
                        f.close()
                    print(str(event.chat_id)) 
                    vk.messages.send(chat_id=event.chat_id, message = str(event.chat_id)+" "+str(event.obj.peer_id),random_id = random(10000,100000))
                    сс = vk.messages.getConversationMembers(peer_id = 2000000000 + event.chat_id)
                    print(cc)
                    """
                    ls = json.load(open("bd.json", "r", encoding="utf-8"))
                    for i in range(0,cc.count):
                        if str(cc.items[i].member_id) in ls:
                            if cc.items[i].is_owner:
                                ls = json.load(open("bd.json", "r", encoding="utf-8"))
                                ls[str(user_id)].update({"conv":{str(event.chat_id):{"lvl":10}}})
                                with open('bd.json', 'w', encoding="utf-8") as f:
                                    json.dump(ls, f, indent=4, ensure_ascii = False)
                                    f.close()
                            if cc.items[i].is_admin:
                                ls = json.load(open("bd.json", "r", encoding="utf-8"))
                                ls[str(user_id)].update({"conv":{str(event.chat_id):{"lvl":5}}})
                                with open('bd.json', 'w', encoding="utf-8") as f:
                                    json.dump(ls, f, indent=4, ensure_ascii = False)
                                    f.close()
                        else:
                            ids = {str(cc.items[i].member_id):{}}
                            upd(ids)
                    ls.close()
                    """



                print('Новое сообщение:')
                print('Для меня от: ', end='')
                print(event.obj.from_id)
                print('Текст:', event.obj.text)
                print()
                

            elif event.type == VkBotEventType.MESSAGE_NEW and event.from_user:
                text = str(event.obj.text)

                if text.lower().startswith("спокойной ночи") and str(event.obj.from_id) == "506520476":
                    vk.messages.send(user_id = int(event.obj.from_id),message = "Сладких снов, дорогой создатель! \n Я люблю тебя))" ,random_id = random(10000,100000))

                if text.lower().startswith('лицензия'):
                    ls = text.split(' ')
                    name = ls[1] + ' ' + ls[2]
                    loli_license(name)
                    a = vk.photos.getMessagesUploadServer()
                    b = requests.post(a['upload_url'], files={'photo': open('/root/vkbot-env/loli2.png', 'rb')}).json()
                    c = vk.photos.saveMessagesPhoto(photo = b['photo'], server = b['server'], hash = b['hash'])[0]
                    d = 'photo{}_{}'.format(c['owner_id'], c['id'])
                    vk.messages.send(user_id = event.obj.from_id, attachment = d, random_id = random(10000,100000))

                  

                if event.obj.text == "Начать":
                    nach = "Привет, я бот Юки. Могу подарить тебе скромный подарочек) Напиши мне \"Пак\" и забирай 10к лолек!"
                    today = datetime.datetime.today()
                    strr = today.strftime("%d.%m.%Y %H:%M:%S") + ', Text from: '+str(event.obj.from_id)+ ', Text: '+str(event.obj.text) + " Status: Completed"
                    vk.messages.send(user_id = int(event.obj.from_id),message = nach ,random_id = random(10000,100000), keyboard = keyboard.get_keyboard())
                    vk.messages.send(user_id=550760548,message = strr ,random_id = random(10000,100000))
                    ls = json.load(open("bd.json", "r", encoding="utf-8"))
                    if (str(event.obj.from_id) in ls) == False:
                        ids = {str(event.obj.from_id):{}}
                        upd(ids)
                
                elif event.obj.text == 'Пак' or event.obj.text == 'пак':
                    if vk.groups.isMember(group_id = '166545677', user_id = event.obj.from_id) == 1:
                        today = datetime.datetime.today()
                        strr = today.strftime("%d.%m.%Y %H:%M:%S") + ', Text from: '+str(event.obj.from_id)+ ', Text: '+str(event.obj.text) + " Status: Completed"
                        vk.messages.send(user_id = int(event.obj.from_id),message ="https://yadi.sk/d/LIIC7R4_3ZrwDh  Вот ваш пак, хозяин",random_id = random(10000,100000))
                        vk.messages.send(user_id=550760548,message = strr ,random_id = random(10000,100000))
                        ls = json.load(open("bd.json", "r", encoding="utf-8"))
                        if (str(event.obj.from_id) in ls) == False:
                            ids = {str(event.obj.from_id):{}}
                            upd(ids) 
                    else:
                        vk.messages.send(user_id = int(event.obj.from_id),message ="Ты не подписался, но все равно просишь пак? Даю в последний раз...\n https://yadi.sk/d/LIIC7R4_3ZrwDh",random_id = random(10000,100000))
                else:
                    today = datetime.datetime.today()
                    strr = today.strftime("%d.%m.%Y %H:%M:%S") + ', Text from: '+str(event.obj.from_id)+ ', Text: '+str(event.obj.text) + " Status: Completed"
                    vk.messages.send(user_id = int(event.obj.from_id),message ="Простите, я вас не поняла... Напишите Пак или Начать",random_id = random(10000,100000))
    
            elif event.type == VkBotEventType.GROUP_JOIN:
                try:
                    ls = json.load(open("bd.json", "r", encoding="utf-8"))
                    if (str(event.obj.user_id) in ls) == False:
                        ids = {str(event.obj.user_id):{}}
                        upd(ids)
                    vk.messages.send(user_id = int(event.obj.user_id),message ="Добро пожаловать в мою уютную группу, семпай!!! Напиши Начать, чтобы узнать обо мне побольше",random_id = random(10000,100000))
                    
              
                except TypeError:
                    continue

            elif event.type == VkBotEventType.GROUP_LEAVE:
                try:
                    vk.messages.send(user_id = 506520476,message ="ливнул *id{}".format(event.obj.user_id),random_id = random(10000,100000))
                    ls = json.load(open("bd.json", "r", encoding="utf-8"))
                    if (str(event.obj.user_id) in ls) == False:
                        ids = {str(event.obj.user_id):{}}
                        upd(ids)
                    
                    vk.messages.send(user_id = int(event.obj.user_id),message ="Пожалуйста, не уходи!!! Напиши мне, что я сделала не так и я постараюсь исправиться...",random_id = random(10000,100000))
                    
                      
                except:
                    continue



            elif event.type == VkBotEventType.MESSAGE_REPLY:
                print('Новое сообщение:')
                print('От меня для: ', end='')
                print(event.obj.peer_id)
                print('Текст:', event.obj.text)
                print()
    
            else:
                print(event.type)
                print()
    except:
        continue
